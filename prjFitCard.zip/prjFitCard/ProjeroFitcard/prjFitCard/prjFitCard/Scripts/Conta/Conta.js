﻿$(document).ready(function () {
    $('.agencia').mask('000-0');
    $('.conta').mask('00.000-0');

});