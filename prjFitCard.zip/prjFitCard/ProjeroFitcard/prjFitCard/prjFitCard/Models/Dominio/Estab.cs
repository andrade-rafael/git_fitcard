﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using prjFitCard.Models;
using prjFitCard.Models.Dominio;
using System.Globalization;

namespace prjFitCard.Models.Dominio
{
    public class Estab
    {

        private String _razao, _fantasia, _cnpj, _email, _cep, _rua, _bairro, _cidade, _comp, _estado, _telefone, _categoria, _agencia, _conta;
        private int? _numero, _status;
        public int id { get; set; }
        //        
        [DisplayName("RAZÃO SOCIAL:")]
        [StringLength(75, MinimumLength = 5, ErrorMessage = "O campo razão social deve ter entre 5 e 75 caracteres.")]
        [Required(ErrorMessage = "O campo razão social deve ser preenchido.")]
        public String razao { get { return _razao; } set { if (value != null) _razao = value.ToUpper(); else _razao = value; } }
        //
        [DisplayName("NOME FANTASIA:")]
        [StringLength(75, MinimumLength = 5, ErrorMessage = "O campo nome fantasia deve ter entre 5 e 75 caracteres.")]
        public String fantasia { get { return _fantasia; } set { if (value != null) _fantasia = value.ToUpper(); else _fantasia = value; } }
        //
        [DisplayName("CNPJ:")]
        [StringLength(18, MinimumLength = 14, ErrorMessage = "O campo CNPJ deve ter 14 números.")]
        [Required(ErrorMessage = "O campo CNPJ deve ser preenchido.")]
        public String cnpj { get { return _cnpj; } set { if (value != null) _cnpj = value.Replace(".", "").Replace("/", "").Replace("-", ""); else _cnpj = value; } }

        [DisplayName("E-MAIL:")]
        [RegularExpression(@"^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*\s+<(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})>$|^(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})$", ErrorMessage = "E-mail inválido.")]
        public String email { get { return _email; } set { if (value != null) _email = value.ToLower(); else _email = value; } }
        //
        [DisplayName("CEP:")]
        [StringLength(9, MinimumLength = 8, ErrorMessage = "O campo CEP deve ter entre 8 números.")]
        public String cep { get { return _cep; } set { if (value != null) _cep = value.Replace("-", ""); else _cep = value; } }
        //
        [DisplayName("RUA:")]
        [StringLength(75, MinimumLength = 5, ErrorMessage = "O campo rua deve ter entre 5 e 75 caracteres.")]
        public String rua { get { return _rua; } set { if (value != null) _rua = value.ToUpper(); else _rua = value; } }
        //
        [DisplayName("NÚMERO:")]
        public int? numero { get { return _numero; } set { if (value == null) _numero = 0; else _numero = value; } }
        //
        [DisplayName("BAIRRO:")]
        [StringLength(75, MinimumLength = 5, ErrorMessage = "O campo bairro deve ter entre 5 e 75 caracteres.")]
        public String bairro { get { return _bairro; } set { if (value != null) _bairro = value.ToUpper(); else _bairro = value; } }
        //
        [DisplayName("CIDADE:")]
        [StringLength(75, MinimumLength = 5, ErrorMessage = "O campo cidade deve ter entre 5 e 75 caracteres.")]
        public String cidade { get { return _cidade; } set { if (value != null) _cidade = value.ToUpper(); else _cidade = value; } }
        //
        [DisplayName("COMPLEMENTO:")]
        [StringLength(75, MinimumLength = 4, ErrorMessage = "O campo complemento deve ter entre 5 e 75 caracteres.")]
        public String comp { get { return _comp; } set { if (value != null) _comp = value.ToUpper(); else _comp = value; } }
        //
        [DisplayName("ESTADO:")]
        public String estado { get { return _estado; } set { if (value != null) _estado = value.ToUpper(); else _estado = value; } }
        //
        [DisplayName("TELEFONE:")]
        [StringLength(14, MinimumLength = 10, ErrorMessage = "O campo telefone deve ter entre 10 e 11 números.")]
        public String telefone { get { return _telefone; } set { if (value != null) _telefone = value.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", ""); else _telefone = value; } }
        //
        [DisplayName("DATA DE CADASTRO:")]
        public DateTime? data_cadastro { get; set; }
        //
        [DisplayName("CATEGORIA:")]
        public String categoria { get { return _categoria; } set { if (value != null) _categoria = value.ToUpper(); else _categoria = value; } }

        //
        [DisplayName("STATUS:")]
        public int? status_estab { get { return _status; } set { if (value == null) _status = 0; else _status = value; } }
        //
        [DisplayName("AGÊNCIA:")]
        [StringLength(5, MinimumLength = 4, ErrorMessage = "O campo agência deve ter 4 números.")]
        public String agencia { get { return _agencia; } set { if (value != null)  _agencia = value.Replace("-", ""); else _agencia = value; } }
        //
        [DisplayName("CONTA:")]
        [StringLength(8, MinimumLength = 6, ErrorMessage = "O campo conta deve ter 6 números.")]
        public String conta { get { return _conta; } set { if (value != null) _conta = value.Replace(".", "").Replace("-", ""); else _conta = value; } }
    }
}