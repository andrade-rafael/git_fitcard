﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using prjFitCard.Models.Repositorio;
using prjFitCard.Models.Dominio;
using System.Globalization;

namespace prjFitCard.Models.Aplicacao
{
    public class EstabAplicacao
    {
        private Contexto contexto;
        
        private void Inserir(Estab estab)
        {
            DateTime? dataBr = estab.data_cadastro;
            String dataEng = Convert.ToDateTime(dataBr).ToString("yyyy-MM-dd");

            var strQuery = "";
            strQuery += " INSERT INTO estab (razao, fantasia, cnpj, email, cep, rua, numero, bairro, cidade, comp, estado,"
            + " telefone, data_cadastro, categoria, status_estab, agencia, conta) ";
            strQuery += string.Format(" VALUES ('{0}','{1}','{2}','{3}','{4}','{5}',{6},'{7}','{8}','{9}','{10}','{11}'," +
                "'{12}','{13}',{14},'{15}','{16}') ", estab.razao, estab.fantasia, estab.cnpj, estab.email, estab.cep,
                estab.rua, estab.numero, estab.bairro, estab.cidade, estab.comp, estab.estado, estab.telefone, dataEng,
                estab.categoria, estab.status_estab, estab.agencia, estab.conta);
            using (contexto = new Contexto())
            {

                contexto.executarComando(strQuery);
            }
        }

        private void Alterar(Estab estab)
        {
            var strQuery = "";
            strQuery += " UPDATE estab SET ";
            strQuery += string.Format(" razao = '{0}', ", estab.razao);
            strQuery += string.Format(" fantasia = '{0}', ", estab.fantasia);
            strQuery += string.Format(" cnpj = '{0}', ", estab.cnpj);
            strQuery += string.Format(" email = '{0}', ", estab.email);
            strQuery += string.Format(" cep = '{0}', ", estab.cep);
            strQuery += string.Format(" rua = '{0}', ", estab.rua);
            strQuery += string.Format(" numero = {0}, ", estab.numero);
            strQuery += string.Format(" bairro = '{0}', ", estab.bairro);
            strQuery += string.Format(" cidade = '{0}', ", estab.cidade);
            strQuery += string.Format(" comp = '{0}', ", estab.comp);
            strQuery += string.Format(" estado = '{0}', ", estab.estado);
            strQuery += string.Format(" telefone = '{0}', ", estab.telefone);
            strQuery += string.Format(" data_cadastro = '{0}', ", estab.data_cadastro);
            strQuery += string.Format(" categoria = '{0}', ", estab.categoria);
            strQuery += string.Format(" status_estab = {0}, ", estab.status_estab);
            strQuery += string.Format(" agencia = '{0}', ", estab.agencia);
            strQuery += string.Format(" conta = '{0}' ", estab.conta);
            strQuery += string.Format(" WHERE id_estab = {0} ", estab.id);
            using (contexto = new Contexto())
            {
                contexto.executarComando(strQuery);
            }
        }

        public void Salvar(Estab estab)
        {
            if (estab.id > 0)
                Alterar(estab);
            else
                Inserir(estab);
        }

        public void Excluir(int id)
        {
            using (contexto = new Contexto())
            {
                var strQuery = string.Format(" DELETE FROM estab WHERE id_estab = {0}", id);
                contexto.executarComando(strQuery);
            }
        }

        public List<Estab> ListarTodos()
        {
            using (contexto = new Contexto())
            {
                var strQuery = " SELECT * FROM estab ";
                var retornoDataReader = contexto.executarComandoComRetorno(strQuery);
                return TransformaReaderEmListaDeObjeto(retornoDataReader);
            }
        }

        public Estab ListarPorId(int id)
        {
            using (contexto = new Contexto())
            {
                var strQuery = string.Format(" SELECT * FROM estab WHERE id_estab = {0} ", id);
                var retornoDataReader = contexto.executarComandoComRetorno(strQuery);
                return TransformaReaderEmListaDeObjeto(retornoDataReader).FirstOrDefault();
            }
        }

        private List<Estab> TransformaReaderEmListaDeObjeto(MySql.Data.MySqlClient.MySqlDataReader reader)
        {
            try
            {
                var estab = new List<Estab>();
                while (reader.Read())
                {
                    var temObjeto = new Estab()
                    {
                        id = int.Parse(reader["id_estab"].ToString()),
                        razao = reader["razao"].ToString(),
                        fantasia = reader["fantasia"].ToString(),
                        cnpj = reader["cnpj"].ToString(),
                        email = reader["email"].ToString(),
                        cep = reader["cep"].ToString(),
                        rua = reader["rua"].ToString(),
                        numero = int.Parse(reader["numero"].ToString()),
                        bairro = reader["bairro"].ToString(),
                        cidade = reader["cidade"].ToString(),
                        comp = reader["comp"].ToString(),
                        estado = reader["estado"].ToString(),
                        telefone = reader["telefone"].ToString(),
                        data_cadastro = DateTime.Now,
                        categoria = reader["categoria"].ToString(),
                        status_estab = int.Parse(reader["status_estab"].ToString()),
                        agencia = reader["agencia"].ToString(),
                        conta = reader["conta"].ToString(),
                    };
                    estab.Add(temObjeto);
                }
                reader.Close();
                return estab;
            }
            catch
            {
            }
            return null;
        }
    }
}