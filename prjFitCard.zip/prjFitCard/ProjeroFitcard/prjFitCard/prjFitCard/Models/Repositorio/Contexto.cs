﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace prjFitCard.Models.Repositorio
{
    public class Contexto : IDisposable
    {
        private readonly MySqlConnection conexao;

        public Contexto()            
        {
            conexao = new MySqlConnection(ConfigurationManager.ConnectionStrings["FitCard"].ConnectionString);
            conexao.Open();
        }
        public void executarComando(String strQuery)
        {
            var comando = new MySqlCommand(strQuery, conexao);
            comando.ExecuteNonQuery();
        }

        public MySqlDataReader executarComandoComRetorno(String strQuery)
        {
            var comando = new MySqlCommand(strQuery, conexao);
            return comando.ExecuteReader();
        }

        public void Dispose()
        {
            if (conexao.State.ToString() == "Open")
                conexao.Close();
        }
    }
}